<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="tr<?php echo e($todo->id); ?>">
    <td>
        <input type="checkbox" value="<?php echo e($todo->is_completed); ?>"
            onchange="updateStatus('<?php echo e($todo->id); ?>','<?php echo e($todo->is_completed); ?>')" <?php echo e($todo->is_completed==1 ? 'checked':''); ?>>
    </td>
    <td><?php echo e($todo->title); ?></td>
    <td><?php echo e($todo->created_at); ?></td>
    <td>

        <a href="javascript:;" onclick="destroyItem('<?php echo e($todo->id); ?>')" class="btn btn-danger">Delete</a>
    </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\project\todo_app\resources\views/todo.blade.php ENDPATH**/ ?>