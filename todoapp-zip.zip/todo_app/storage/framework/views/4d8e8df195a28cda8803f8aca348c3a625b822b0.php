<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>

    <div class="row justify-content-center mt-5">
        <div class="col-lg-6">
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 offset-md-3 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"
                            onclick="checkData()">
                        <label class="form-check-label" for="flexCheckDefault">
                            Show All Task
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center mt-2">
        <h2>Add Task</h2>

        <form class="row g-3 justify-content-center" id="storeTask" method="POST">
            <?php echo csrf_field(); ?>
            <div class="col-6">
                <input type="text" class="form-control" name="title" placeholder="Title">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary mb-3">Add</button>
            </div>
            <div class="col-12">
                <div class="invalid-feedback my-2 text-left" id="title_err" style="display:block">
                </div>
            </div>
        </form>
    </div>

    <div class="text-center">
        <h2>All Tasks</h2>
        <div class="row justify-content-center">
            <div class="col-lg-6">

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Created at</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody id="bodyData">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="container">
        <footer class="py-3 my-4">

            <p class="text-center text-muted">Developed By Manpreet Singh</p>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script>
        function checkData(){
            if($('#flexCheckDefault').is(":checked")) {
                get_page_data(2);
            } else{
                get_page_data(1);
                }
            }
        function get_page_data(res) {
       
      var url = "<?php echo e(route('todos.index')); ?>"; //form.attr('action'); login	
      var data = {
          'res': res,
        };
      $.ajax({
        type: "POST",
        url: url,
         data:data,
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(data) {
          $('#bodyData').html(data);
        },
      });
   
    }
    get_page_data(1);
    
    $(document).ready(function() {
    $("#storeTask").submit(function(e) {
        e.preventDefault();
        var url = "<?php echo e(route('todos.store')); ?>";
        $.ajax({
          type: "POST",
          url: url,
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          processData: false,
          cache: false,
          contentType: false,
          data: new FormData(this),         
          success: function(data) {
            var obj = JSON.parse(data);
            checkData();
            if (obj.result == 'success') {
              alert(obj.message);
              $('#storeTask')[0].reset();
            } else {
              alert(obj.message);
            }
          },
          error: function(err) {
            if (err.status == 422) {
              $.each(err.responseJSON.errors, function(i, error) {
                $("#" + i + "_err").html(error[0]);
                document.getElementById(i + "_err").innerHTML = error[0];
                setTimeout(() => {
                  $('.invalid-feedback').html(' ');
                }, 10000);
              });
            }
            if (err.status == 419) { // when status code is 419, it's a validation issue
              setTimeout(() => {
                window.location.reload();
              }, 2000);
            }
          }

        });
      });
    });

    
        function destroyItem(id) {
      if (confirm("Are you sure. you want to delete this task.")) {
        var url = "<?php echo e(route('todos.delete')); ?>";
        var data = {
          'to_id': id,
        };
        $.ajax({
          type: "DELETE",
          url: url,
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          data: data,
          success: function(data) {
            if (data == 'success') {
                $('#tr'+id).fadeOut(0);
                alert('Task deleted success!!');
            }
          },
        });
      }
    }

    function updateStatus(id,status){
        var url = "<?php echo e(route('todos.status')); ?>";
        var data = {
          'to_id': id,
          'status': status,
        };
        $.ajax({
          type: "POST",
          url: url,
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          data: data,
          success: function(data) {
            var obj = JSON.parse(data);
            if (obj.result == 'success') {
              alert(obj.message);           
              checkData();     
            }else{
                alert(obj.message);                
            }
          },
        });
    }
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\project\todo_app\resources\views/welcome.blade.php ENDPATH**/ ?>