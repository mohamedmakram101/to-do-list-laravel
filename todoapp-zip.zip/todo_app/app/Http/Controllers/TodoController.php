<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Todo;
use Illuminate\Support\Facades\Validator;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $rslt  = $request->res;
        $todos = Todo::where(function ($query) use ($rslt) {
            if ($rslt == 1) {
                $query->where('is_completed', 0);
            }
        })->latest()->get();
        return view('todo', compact('todos'));
    }
    public function index2()
    {
        return view('welcome');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator  = $request->validate([
            'title' => 'required|string|unique:todos,title',
        ]);
        $obj        = new Todo();
        $obj->title = $request->title;
        $obj->save();
        if ($obj->save()) {
            $arr = array(
                'result'  => "success",
                'message' => 'Added successfully.',
            );
        } else {
            $arr = array(
                'result'  => "failure",
                'message' => 'Unable to add task.',
            );
        }
        echo json_encode($arr);

    }

    public function updateStatus(Request $request)
    {
        $validator         = $request->validate([
            'to_id'  => 'required',
            'status' => 'required',
        ]);
        $obj               = Todo::where('id', $request->to_id)->first();
        $obj->is_completed = 1;
        if ($obj->save()) {
            $res = "success";
            $mm  = 'Task Completed.';
        } else {
            $res = "failure";
            $mm  = 'somthing went wrong';
        }
        $arr = array(
            'result'  => $res,
            'message' => $mm,
        );
        echo json_encode($arr);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        $obj = Todo::where('id', $request->to_id)->delete();
        $msg = "failed";
        if ($obj) {
            $msg = "success";
        }
        echo $msg;
    }
}