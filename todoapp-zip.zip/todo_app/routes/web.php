<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TodoController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::resource('todos', TodoController::class);
// Route::delete('todos', [TodoController::class, 'destroy'])->name('todo.delete');
Route::get('/', [TodoController::class, 'index2'])->name('todos.index2');
Route::post('todos', [TodoController::class, 'index'])->name('todos.index');
Route::post('todos-save', [TodoController::class, 'store'])->name('todos.store');
Route::post('todos-status', [TodoController::class, 'updateStatus'])->name('todos.status');
Route::delete('todos-delete', [TodoController::class, 'delete'])->name('todos.delete');

// Route::post('todo-list', [HomeController::class, 'show'])->name('todo-list');

// Route::get('/', function () {
//     return view('welcome');
// });