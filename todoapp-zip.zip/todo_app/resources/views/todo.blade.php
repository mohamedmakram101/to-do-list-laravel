@foreach($todos as $todo)
<tr id="tr{{ $todo->id}}">
    <td>
        <input type="checkbox" value="{{$todo->is_completed}}"
            onchange="updateStatus('{{ $todo->id}}','{{$todo->is_completed}}')" {{ $todo->is_completed==1 ? 'checked':''
        }}>
    </td>
    <td>{{$todo->title}}</td>
    <td>{{$todo->created_at}}</td>
    <td>

        <a href="javascript:;" onclick="destroyItem('{{ $todo->id}}')" class="btn btn-danger">Delete</a>
    </td>
</tr>

@endforeach